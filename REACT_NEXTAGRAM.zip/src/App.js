import React from 'react'
import { Route, Link } from "react-router-dom"

import './App.css'

import HomePage from './pages/HomePage'
import UserProfilePage from './pages/UserProfilePage'

function App() {


  return (
    // <div className="App">
    //  <HomePage />
    // </div>
    <div>
      <Link to="/">Home</Link>
      {/* We temporarily hardcode this to user id 1*/}
      <Link to="/users/1">My Profile</Link>

      <Route exact path="/" component={HomePage} />
      <Route path="/users/:id" component={UserProfilePage} />
    </div>
  );
}

export default App;
